<?php $__env->startSection('title', 'Register patient'); ?>
<?php $__env->startSection('content'); ?>
<div class="panel pad" style="max-width:560px;margin:0 auto">
    <h2>Register patient</h2>
    <?php echo $__env->make('patients._form', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Sam\my-first-app\resources\views/patients/create.blade.php ENDPATH**/ ?>