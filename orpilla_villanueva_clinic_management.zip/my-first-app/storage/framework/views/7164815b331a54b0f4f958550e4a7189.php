<form method="POST" action="<?php echo e($patient->exists ? route('patients.update', $patient) : route('patients.store')); ?>">
    <?php echo csrf_field(); ?>
    <?php if($patient->exists): ?> <?php echo method_field('PUT'); ?> <?php endif; ?>
    <div class="grid">
        <div>
            <label for="last_name">Last name</label>
            <input id="last_name" name="last_name" value="<?php echo e(old('last_name', $patient->last_name)); ?>" required>
            <?php $__errorArgs = ['last_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label for="first_name">First name</label>
            <input id="first_name" name="first_name" value="<?php echo e(old('first_name', $patient->first_name)); ?>" required>
            <?php $__errorArgs = ['first_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label for="birth_date">Birth date</label>
            <input id="birth_date" type="date" name="birth_date" max="<?php echo e(now()->toDateString()); ?>" value="<?php echo e(old('birth_date', $patient->birth_date?->format('Y-m-d'))); ?>" required>
            <?php $__errorArgs = ['birth_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div>
            <label for="sex">Sex</label>
            <select id="sex" name="sex" required>
                <option value="">Select</option>
                <?php $__currentLoopData = ['Female', 'Male']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($s); ?>" <?php if(old('sex', $patient->sex) === $s): echo 'selected'; endif; ?>><?php echo e($s); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            <?php $__errorArgs = ['sex'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="full">
            <label for="contact_number">Contact number</label>
            <input id="contact_number" type="tel" name="contact_number" value="<?php echo e(old('contact_number', $patient->contact_number)); ?>" required>
            <?php $__errorArgs = ['contact_number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
        <div class="full">
            <label for="address">Address (optional)</label>
            <textarea id="address" name="address" rows="2"><?php echo e(old('address', $patient->address)); ?></textarea>
            <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?><div class="err"><?php echo e($message); ?></div><?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
    <div class="actions">
        <a class="btn" href="<?php echo e(route('patients.index')); ?>">Cancel</a>
        <button class="btn primary" type="submit">Save patient</button>
    </div>
</form>
<?php /**PATH C:\Users\Sam\my-first-app\resources\views/patients/_form.blade.php ENDPATH**/ ?>