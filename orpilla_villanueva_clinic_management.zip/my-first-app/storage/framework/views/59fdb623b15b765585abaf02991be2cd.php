<?php $__env->startSection('content'); ?>
<header class="hero">
    <div>
        <span class="pill">Clinic dashboard</span>
        <h1>Patient records</h1>
        <p>Register, update and look up clinic patients.</p>
    </div>
    <a class="btn" href="<?php echo e(route('patients.create')); ?>">+ Register patient</a>
</header>

<section class="stats">
    <div class="stat"><span>Total patients</span><b><?php echo e($total); ?></b></div>
    <div class="stat"><span>Female</span><b><?php echo e($female); ?></b></div>
    <div class="stat"><span>Male</span><b><?php echo e($male); ?></b></div>
</section>

<section class="panel">
    <form class="bar" method="GET" action="<?php echo e(route('patients.index')); ?>">
        <input type="search" name="q" value="<?php echo e($q); ?>" placeholder="Search by patient number or name" aria-label="Search patients">
        <button class="btn primary" type="submit">Search</button>
        <?php if($q !== ''): ?>
            <a class="btn" href="<?php echo e(route('patients.index')); ?>">Clear</a>
        <?php endif; ?>
    </form>

    <?php if($patients->count()): ?>
    <div class="tablewrap">
        <table>
            <thead>
                <tr><th>Patient no.</th><th>Name</th><th>Birth date</th><th>Sex</th><th>Contact</th><th></th></tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td class="id"><?php echo e($p->patient_no); ?></td>
                    <td><div class="who"><span class="av"><?php echo e($p->initials); ?></span><?php echo e($p->full_name); ?></div></td>
                    <td><?php echo e($p->birth_date->format('M d, Y')); ?></td>
                    <td><span class="badge <?php echo e($p->sex === 'Female' ? 'f' : 'm'); ?>"><?php echo e($p->sex); ?></span></td>
                    <td><?php echo e($p->contact_number); ?></td>
                    <td class="act">
                        <a class="btn link" href="<?php echo e(route('patients.show', $p)); ?>">View</a>
                        <a class="btn link" href="<?php echo e(route('patients.edit', $p)); ?>">Edit</a>
                        <form method="POST" action="<?php echo e(route('patients.destroy', $p)); ?>" onsubmit="return confirm('Delete <?php echo e(addslashes($p->full_name)); ?> (<?php echo e($p->patient_no); ?>)? This can’t be undone.')">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button class="btn danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div class="foot">
        <span>Showing <?php echo e($patients->firstItem()); ?> to <?php echo e($patients->lastItem()); ?> of <?php echo e($patients->total()); ?> patients</span>
        <span>
            <?php if($patients->previousPageUrl()): ?><a class="btn" href="<?php echo e($patients->previousPageUrl()); ?>">Previous</a><?php endif; ?>
            <?php if($patients->nextPageUrl()): ?><a class="btn" href="<?php echo e($patients->nextPageUrl()); ?>">Next</a><?php endif; ?>
        </span>
    </div>
    <?php else: ?>
        <div class="empty"><?php echo e($q !== '' ? 'No patients match your search.' : 'No patients yet. Register your first patient to get started.'); ?></div>
    <?php endif; ?>
</section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Sam\my-first-app\resources\views/patients/index.blade.php ENDPATH**/ ?>