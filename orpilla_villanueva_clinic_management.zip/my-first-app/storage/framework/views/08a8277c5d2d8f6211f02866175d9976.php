<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?php echo $__env->yieldContent('title', 'Patient Records'); ?></title>
<link href="https://fonts.googleapis.com/css2?family=Figtree:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
:root{--bg:#f2f4fb;--surface:#fff;--ink:#161a33;--muted:#6a7090;--line:#e5e8f4;--primary:#5046e5;--soft:#eceeff;--danger:#e0475b;--danger-soft:#ffecef;--grad:linear-gradient(120deg,#4f46e5,#7c3aed 55%,#06b6d4);--shadow:0 8px 30px rgba(60,60,140,.10)}
@media (prefers-color-scheme:dark){:root{--bg:#0c0e1d;--surface:#151833;--ink:#eceefd;--muted:#9aa0c7;--line:#262a52;--primary:#8b84ff;--soft:#20244b;--danger:#ff7d8e;--danger-soft:#33192a}}
*,*::before,*::after{box-sizing:border-box}
body{margin:0;background:radial-gradient(900px 400px at 85% -100px,rgba(124,58,237,.14),transparent),var(--bg);color:var(--ink);font:400 15px/1.5 Figtree,system-ui,-apple-system,"Segoe UI",sans-serif}
.wrap{max-width:980px;margin:0 auto;padding:40px 20px 64px}
h1{font-size:32px;line-height:1.2;margin:0;font-weight:700;letter-spacing:-.01em}
h2{margin:0 0 16px;font-size:20px}
button,input,select,textarea{font:inherit;color:inherit}
a{color:var(--primary)}
.btn{display:inline-block;border:1px solid var(--line);background:var(--surface);padding:8px 14px;border-radius:10px;cursor:pointer;font-weight:500;text-decoration:none;color:var(--ink)}
.btn:hover{background:var(--soft)}
.btn.primary{background:var(--grad);border:0;color:#fff}
.btn.link{border-color:transparent;background:transparent;color:var(--primary);padding:6px 8px}
.btn.danger{border-color:transparent;background:transparent;color:var(--danger);padding:6px 8px}
.btn.danger:hover{background:var(--danger-soft)}
:focus-visible{outline:2px solid var(--primary);outline-offset:2px}
.hero{background:var(--grad);color:#fff;border-radius:20px;padding:32px;box-shadow:var(--shadow);position:relative;overflow:hidden;margin-bottom:20px;display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}
.hero::after{content:"";position:absolute;right:-60px;top:-80px;width:260px;height:260px;border-radius:50%;background:rgba(255,255,255,.14)}
.hero p{margin:4px 0 0;color:rgba(255,255,255,.85)}
.hero .btn{background:#fff;color:#4f46e5;font-weight:700;padding:11px 18px;border-radius:12px;position:relative;z-index:1;box-shadow:0 6px 18px rgba(0,0,0,.18)}
.pill{display:inline-block;background:rgba(255,255,255,.2);padding:3px 10px;border-radius:99px;font-size:12px;font-weight:600;margin-bottom:8px}
.stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:14px;margin-bottom:20px}
.stat{background:var(--surface);border:1px solid var(--line);border-radius:16px;padding:16px 18px;box-shadow:var(--shadow);display:flex;flex-direction:column}
.stat span{color:var(--muted);font-size:13px}.stat b{font-size:28px;line-height:1.2}
.panel{background:var(--surface);border:1px solid var(--line);border-radius:20px;box-shadow:var(--shadow);overflow:hidden}
.pad{padding:24px}
.bar{display:flex;gap:10px;padding:14px;border-bottom:1px solid var(--line);flex-wrap:wrap}
.bar input{flex:1;min-width:180px}
input,select,textarea{width:100%;padding:9px 12px;border:1px solid var(--line);border-radius:10px;background:var(--bg)}
input:focus,select:focus,textarea:focus{border-color:var(--primary);outline:none;box-shadow:0 0 0 3px var(--soft)}
.tablewrap{overflow-x:auto}
table{width:100%;border-collapse:collapse;min-width:640px}
th,td{text-align:left;padding:12px 16px;border-bottom:1px solid var(--line);white-space:nowrap}
th{font-weight:600;color:var(--muted);font-size:13px;background:var(--bg)}
tbody tr:hover{background:var(--bg)}
td.id{color:var(--primary);font-weight:600}
td.act{text-align:right}td.act form{display:inline}
.who{display:flex;align-items:center;gap:12px}
.av{width:36px;height:36px;border-radius:50%;display:grid;place-items:center;font-weight:700;font-size:13px;color:#fff;background:var(--grad);flex:none}
.badge{padding:3px 10px;border-radius:99px;font-size:12px;font-weight:600}
.badge.f{background:#fde7f3;color:#b0286f}.badge.m{background:#e3f0ff;color:#1f5fbf}
.empty{padding:48px 16px;text-align:center;color:var(--muted)}
.foot{display:flex;justify-content:space-between;align-items:center;padding:14px 16px;color:var(--muted);font-size:14px;gap:10px;flex-wrap:wrap}
.flash{background:var(--soft);border:1px solid var(--primary);color:var(--ink);padding:10px 16px;border-radius:12px;margin-bottom:16px;font-weight:500}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}.full{grid-column:1/-1}
label{display:block;font-size:13px;font-weight:500;margin-bottom:4px;color:var(--muted)}
.err{color:var(--danger);font-size:12px;margin-top:3px}
.actions{display:flex;gap:8px;justify-content:flex-end;margin-top:20px}
dl{display:grid;grid-template-columns:140px 1fr;gap:12px;margin:0 0 8px}dt{color:var(--muted)}dd{margin:0;font-weight:500}
@media (max-width:560px){.grid{grid-template-columns:1fr}dl{grid-template-columns:110px 1fr}}
</style>
</head>
<body>
<div class="wrap">
    <?php if(session('status')): ?>
        <div class="flash" role="status"><?php echo e(session('status')); ?></div>
    <?php endif; ?>
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
</html>
<?php /**PATH C:\Users\Sam\my-first-app\resources\views/layouts/app.blade.php ENDPATH**/ ?>