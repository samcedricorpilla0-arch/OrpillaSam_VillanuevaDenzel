<?php

namespace App\Http\Controllers;

use App\Models\Patient;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\View\View;

class PatientController extends Controller
{
    public function index(Request $request): View
    {
        $q = trim((string) $request->query('q', ''));

        $patients = Patient::query()
            ->when($q !== '', function ($query) use ($q) {
                $query->where(function ($w) use ($q) {
                    $w->where('patient_no', 'like', "%{$q}%")
                        ->orWhere('first_name', 'like', "%{$q}%")
                        ->orWhere('last_name', 'like', "%{$q}%");
                });
            })
            ->orderBy('patient_no')
            ->paginate(10)
            ->withQueryString();

        return view('patients.index', [
            'patients' => $patients,
            'q' => $q,
            'total' => Patient::count(),
            'female' => Patient::where('sex', 'Female')->count(),
            'male' => Patient::where('sex', 'Male')->count(),
        ]);
    }

    public function create(): View
    {
        return view('patients.create', ['patient' => new Patient()]);
    }

    public function store(Request $request): RedirectResponse
    {
        Patient::create($this->validated($request));

        return redirect()->route('patients.index')->with('status', 'Patient registered.');
    }

    public function show(Patient $patient): View
    {
        return view('patients.show', compact('patient'));
    }

    public function edit(Patient $patient): View
    {
        return view('patients.edit', compact('patient'));
    }

    public function update(Request $request, Patient $patient): RedirectResponse
    {
        $patient->update($this->validated($request));

        return redirect()->route('patients.index')->with('status', 'Patient updated.');
    }

    public function destroy(Patient $patient): RedirectResponse
    {
        $patient->delete();

        return redirect()->route('patients.index')->with('status', 'Patient deleted.');
    }

    private function validated(Request $request): array
    {
        return $request->validate([
            'last_name' => ['required', 'string', 'max:100'],
            'first_name' => ['required', 'string', 'max:100'],
            'birth_date' => ['required', 'date', 'before_or_equal:today'],
            'sex' => ['required', 'in:Female,Male'],
            'contact_number' => ['required', 'regex:/^[0-9+\-\s()]{7,15}$/'],
            'address' => ['nullable', 'string', 'max:500'],
        ], [
            'contact_number.regex' => 'Enter a valid contact number.',
            'birth_date.before_or_equal' => 'Birth date can’t be in the future.',
        ]);
    }
}
