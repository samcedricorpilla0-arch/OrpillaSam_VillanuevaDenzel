@extends('layouts.app')
@section('title', 'Edit patient')
@section('content')
<div class="panel pad" style="max-width:560px;margin:0 auto">
    <h2>Edit {{ $patient->patient_no }}</h2>
    @include('patients._form')
</div>
@endsection
