<form method="POST" action="{{ $patient->exists ? route('patients.update', $patient) : route('patients.store') }}">
    @csrf
    @if ($patient->exists) @method('PUT') @endif
    <div class="grid">
        <div>
            <label for="last_name">Last name</label>
            <input id="last_name" name="last_name" value="{{ old('last_name', $patient->last_name) }}" required>
            @error('last_name')<div class="err">{{ $message }}</div>@enderror
        </div>
        <div>
            <label for="first_name">First name</label>
            <input id="first_name" name="first_name" value="{{ old('first_name', $patient->first_name) }}" required>
            @error('first_name')<div class="err">{{ $message }}</div>@enderror
        </div>
        <div>
            <label for="birth_date">Birth date</label>
            <input id="birth_date" type="date" name="birth_date" max="{{ now()->toDateString() }}" value="{{ old('birth_date', $patient->birth_date?->format('Y-m-d')) }}" required>
            @error('birth_date')<div class="err">{{ $message }}</div>@enderror
        </div>
        <div>
            <label for="sex">Sex</label>
            <select id="sex" name="sex" required>
                <option value="">Select</option>
                @foreach (['Female', 'Male'] as $s)
                    <option value="{{ $s }}" @selected(old('sex', $patient->sex) === $s)>{{ $s }}</option>
                @endforeach
            </select>
            @error('sex')<div class="err">{{ $message }}</div>@enderror
        </div>
        <div class="full">
            <label for="contact_number">Contact number</label>
            <input id="contact_number" type="tel" name="contact_number" value="{{ old('contact_number', $patient->contact_number) }}" required>
            @error('contact_number')<div class="err">{{ $message }}</div>@enderror
        </div>
        <div class="full">
            <label for="address">Address (optional)</label>
            <textarea id="address" name="address" rows="2">{{ old('address', $patient->address) }}</textarea>
            @error('address')<div class="err">{{ $message }}</div>@enderror
        </div>
    </div>
    <div class="actions">
        <a class="btn" href="{{ route('patients.index') }}">Cancel</a>
        <button class="btn primary" type="submit">Save patient</button>
    </div>
</form>
