@extends('layouts.app')

@section('content')
<header class="hero">
    <div>
        <span class="pill">Clinic dashboard</span>
        <h1>Patient records</h1>
        <p>Register, update and look up clinic patients.</p>
    </div>
    <a class="btn" href="{{ route('patients.create') }}">+ Register patient</a>
</header>

<section class="stats">
    <div class="stat"><span>Total patients</span><b>{{ $total }}</b></div>
    <div class="stat"><span>Female</span><b>{{ $female }}</b></div>
    <div class="stat"><span>Male</span><b>{{ $male }}</b></div>
</section>

<section class="panel">
    <form class="bar" method="GET" action="{{ route('patients.index') }}">
        <input type="search" name="q" value="{{ $q }}" placeholder="Search by patient number or name" aria-label="Search patients">
        <button class="btn primary" type="submit">Search</button>
        @if ($q !== '')
            <a class="btn" href="{{ route('patients.index') }}">Clear</a>
        @endif
    </form>

    @if ($patients->count())
    <div class="tablewrap">
        <table>
            <thead>
                <tr><th>Patient no.</th><th>Name</th><th>Birth date</th><th>Sex</th><th>Contact</th><th></th></tr>
            </thead>
            <tbody>
            @foreach ($patients as $p)
                <tr>
                    <td class="id">{{ $p->patient_no }}</td>
                    <td><div class="who"><span class="av">{{ $p->initials }}</span>{{ $p->full_name }}</div></td>
                    <td>{{ $p->birth_date->format('M d, Y') }}</td>
                    <td><span class="badge {{ $p->sex === 'Female' ? 'f' : 'm' }}">{{ $p->sex }}</span></td>
                    <td>{{ $p->contact_number }}</td>
                    <td class="act">
                        <a class="btn link" href="{{ route('patients.show', $p) }}">View</a>
                        <a class="btn link" href="{{ route('patients.edit', $p) }}">Edit</a>
                        <form method="POST" action="{{ route('patients.destroy', $p) }}" onsubmit="return confirm('Delete {{ addslashes($p->full_name) }} ({{ $p->patient_no }})? This can’t be undone.')">
                            @csrf
                            @method('DELETE')
                            <button class="btn danger" type="submit">Delete</button>
                        </form>
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </div>
    <div class="foot">
        <span>Showing {{ $patients->firstItem() }} to {{ $patients->lastItem() }} of {{ $patients->total() }} patients</span>
        <span>
            @if ($patients->previousPageUrl())<a class="btn" href="{{ $patients->previousPageUrl() }}">Previous</a>@endif
            @if ($patients->nextPageUrl())<a class="btn" href="{{ $patients->nextPageUrl() }}">Next</a>@endif
        </span>
    </div>
    @else
        <div class="empty">{{ $q !== '' ? 'No patients match your search.' : 'No patients yet. Register your first patient to get started.' }}</div>
    @endif
</section>
@endsection
