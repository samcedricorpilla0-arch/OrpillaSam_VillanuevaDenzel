@extends('layouts.app')
@section('title', $patient->full_name)
@section('content')
<div class="panel pad" style="max-width:560px;margin:0 auto">
    <div class="who" style="margin-bottom:20px">
        <span class="av" style="width:48px;height:48px;font-size:16px">{{ $patient->initials }}</span>
        <h2 style="margin:0">{{ $patient->full_name }}</h2>
    </div>
    <dl>
        <dt>Patient no.</dt><dd>{{ $patient->patient_no }}</dd>
        <dt>Birth date</dt><dd>{{ $patient->birth_date->format('M d, Y') }}</dd>
        <dt>Sex</dt><dd>{{ $patient->sex }}</dd>
        <dt>Contact</dt><dd>{{ $patient->contact_number }}</dd>
        <dt>Address</dt><dd>{{ $patient->address ?: 'Not provided' }}</dd>
    </dl>
    <div class="actions">
        <a class="btn" href="{{ route('patients.index') }}">Back to list</a>
        <a class="btn primary" href="{{ route('patients.edit', $patient) }}">Edit patient</a>
    </div>
</div>
@endsection
