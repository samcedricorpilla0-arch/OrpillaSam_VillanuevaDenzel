@extends('layouts.app')
@section('title', 'Register patient')
@section('content')
<div class="panel pad" style="max-width:560px;margin:0 auto">
    <h2>Register patient</h2>
    @include('patients._form')
</div>
@endsection
