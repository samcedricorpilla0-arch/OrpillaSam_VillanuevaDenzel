<?php

use App\Http\Controllers\PatientController;
use Illuminate\Support\Facades\Route;

Route::redirect('/', '/patients');
Route::resource('patients', PatientController::class);
